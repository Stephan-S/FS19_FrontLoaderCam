This mod is used to add an additional camera to every vehicle with a frontloader attachement.
Usage:
FLCam On/Off: Toggle between frontloader camera and last active view (internal or external)
FLCam MoveCam: Hold to enable moving the camera in all directions. 
		x (Look-left,right-axis),
		y (Move-player-forward/backward-axis) and
		z (Look-up-down-axis)